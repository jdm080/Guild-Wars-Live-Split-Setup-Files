
// Guild Wars 1 — EXP Tracking + Milestone Splits + Dynamic Recalculation + Force-Skip Alignment + Pause on Loading and Death
// Process: Gw

state("Gw") {
    int listBase0 : "Gw.exe", 0x007AC2D0, 0x0, 0x18, 0x2C;
}

startup {
    settings.Add("enableSurvivor", false, "Enable Legendary Survivor");
    settings.Add("enableCombo", false, "Enable Combo (Level 20 + Legendary Survivor)");
    settings.Add("enableLogging", true, "Enable debug logging");
    settings.Add("enableForceSkip", true, "Enable force-skip alignment on start");

    vars.INSTANCE_TOWN = 0;
    vars.INSTANCE_EXPLORE = 1;
    vars.INSTANCE_LOADING = 2;
    vars.INSTANCE_CUTSCENE = 3;

    vars.milestones = new int[] {
        2000, 4600, 7800, 11600, 16000, 21000, 26600, 32800, 39600,
        47000, 55000, 63600, 72800, 82600, 93000, 104000, 115600,
        127800, 140600
    };

    vars.visibleFinalGoal = 140600;
    vars.nextMilestoneIndex = 0;
    vars.lastMilestoneValue = 0;
    vars.CurrentXP = 0;
    vars.CurrentXPFormatted = "0";

    vars.deathOverrideActive = false;
    vars.deathCount = 0;
}

init {
    if (settings["enableLogging"]) print("[DEBUG] init started");

    vars.CurrentXP = 0;
    vars.CurrentXPFormatted = "0";
    vars.nextMilestoneIndex = 0;
    vars.lastMilestoneValue = 0;

    var scanner = new SignatureScanner(game, game.MainModule.BaseAddress, (int)game.MainModule.ModuleMemorySize);
    IntPtr ptrBase = scanner.Scan(new SigScanTarget(0xD, "6A 2C 50 E8 ?? ?? ?? ?? 83 C4 08 C7"));
    if (ptrBase == IntPtr.Zero) {
        if (settings["enableLogging"]) print("[DEBUG] Signature scan failed. init aborted.");
        return;
    }

    vars.w_instanceType = new MemoryWatcher<int>(new DeepPointer(ptrBase, 0x4)) { Name = "instanceType" };
    vars.watchers = new MemoryWatcherList();
    vars.watchers.Add(vars.w_instanceType);
    vars.watchers.Add(new MemoryWatcher<int>(new DeepPointer("Gw.exe", 0x7BE7BC)) { Name = "isDead" });

    if (settings["enableLogging"]) print("[DEBUG] init completed successfully");
}

update {
    int baseSel = (int)current.listBase0;
    if (baseSel == 0) return;

    if (vars.watchers != null && game != null && !game.HasExited) vars.watchers.UpdateAll(game);

    // Death flag check
    if (vars.watchers["isDead"].Current == 1) {
        if (!vars.deathOverrideActive) {
            vars.deathCount++;
            if (settings["enableLogging"]) print("[DEBUG] Death detected. Total deaths=" + vars.deathCount);
        }
        vars.deathOverrideActive = true;
    }

    current.DeathCount = vars.deathCount.ToString();

    // Update milestone arrays based on mode
    if (settings["enableCombo"]) {
        vars.milestones = new int[] {
            0, 2000, 4600, 7800, 11600, 16000, 21000, 26600, 32800, 39600,
            47000, 55000, 63600, 72800, 82600, 93000, 104000, 115600,
            127800, 140600, 587500, 1337500
        };
        vars.visibleFinalGoal = 1337500;
    } else if (settings["enableSurvivor"]) {
        vars.milestones = new int[] {0, 140600, 587500, 1337500 };
        vars.visibleFinalGoal = 1337500;
    } else {
        vars.milestones = new int[] {
            2000, 4600, 7800, 11600, 16000, 21000, 26600, 32800, 39600,
            47000, 55000, 63600, 72800, 82600, 93000, 104000, 115600,
            127800, 140600
        };
        vars.visibleFinalGoal = 140600;
    }

    // Read XP
    vars.CurrentXP = memory.ReadValue<int>((IntPtr)(baseSel + 0x740));
    vars.CurrentXPFormatted = System.String.Format("{0:N0}", vars.CurrentXP);

    // ✅ Dynamic recalculation of next milestone index
    vars.nextMilestoneIndex = 0;
    for (int i = 0; i < vars.milestones.Length; i++) {
        if (vars.CurrentXP >= vars.milestones[i]) {
            vars.nextMilestoneIndex = i + 1;
        } else {
            break;
        }
    }
    vars.lastMilestoneValue = (vars.nextMilestoneIndex > 0) ? vars.milestones[vars.nextMilestoneIndex - 1] : 0;

    if (settings["enableLogging"]) {
        print("[DEBUG] Update: CurrentXP=" + vars.CurrentXP +
              " | NextMilestoneIndex=" + vars.nextMilestoneIndex +
              " | LastMilestoneValue=" + vars.lastMilestoneValue +
              " | CurrentSplitIndex=" + timer.CurrentSplitIndex);
    }

    // Update UI
    int idx = vars.nextMilestoneIndex;
    string nextMilestoneText = (idx < vars.milestones.Length) ? vars.milestones[idx].ToString("N0") : "Complete";
    int remaining = (idx < vars.milestones.Length) ? vars.milestones[idx] - vars.CurrentXP : 0;
    if (remaining < 0) remaining = 0;

    current.CurrentXP = vars.CurrentXPFormatted;
    current.XPToNextMilestone = System.String.Format("{0:N0}", remaining);
    current.NextMilestone = nextMilestoneText;
    current.ProgressPercent = ((double)vars.CurrentXP / vars.visibleFinalGoal * 100).ToString("F2") + "%";
    current.Status = "Current: " + vars.CurrentXPFormatted + " | Next: " + nextMilestoneText;
}

start {
    vars.deathOverrideActive = false;

    if (vars.w_instanceType != null &&
        (vars.w_instanceType.Current == vars.INSTANCE_TOWN || vars.w_instanceType.Current == vars.INSTANCE_EXPLORE)) {

        if (settings["enableLogging"]) {
            print("[DEBUG] Start triggered:");
            print("[DEBUG] Current XP: " + vars.CurrentXP);
            print("[DEBUG] Next milestone index: " + vars.nextMilestoneIndex);
            print("[DEBUG] Last milestone threshold: " + vars.lastMilestoneValue);
            print("[DEBUG] Current split index: " + timer.CurrentSplitIndex);
        }

        return true;
    }
    return false;
}

reset { return false; }

onReset {
    vars.nextMilestoneIndex = 0;
    vars.lastMilestoneValue = 0;
    vars.deathOverrideActive = false;

    if (settings["enableLogging"]) {
        print("[DEBUG] Reset: Internal=" + vars.nextMilestoneIndex +
              " | Visual=" + timer.CurrentSplitIndex);
    }
}

split {
    int currentVal = vars.CurrentXP;

    // ✅ Continuous force-skip until visual matches internal milestone
    if (settings["enableForceSkip"] && timer.CurrentSplitIndex < vars.nextMilestoneIndex - 1) {
        if (settings["enableLogging"]) {
            print("[DEBUG] Force skip applied. Visual=" + timer.CurrentSplitIndex +
                  " | Target=" + (vars.nextMilestoneIndex - 1));
        }
        return true; // Keep skipping until aligned
    }

    // ✅ Normal milestone logic
    int idx = vars.nextMilestoneIndex;
    if (idx >= vars.milestones.Length) return false;

    int threshold = vars.milestones[idx];
    bool crossed = (vars.lastMilestoneValue < threshold) && (currentVal >= threshold);

    if (crossed) {
        vars.nextMilestoneIndex = idx + 1;
        vars.lastMilestoneValue = currentVal;
        if (settings["enableLogging"]) {
            print("[DEBUG] Split triggered at milestone index=" + idx +
                  " | XP=" + currentVal + " | Next milestone=" +
                  (vars.nextMilestoneIndex < vars.milestones.Length ? vars.milestones[vars.nextMilestoneIndex] : "Complete"));
        }
        return true;
    }

    vars.lastMilestoneValue = currentVal;
    return false;
}

isLoading {
    return (vars.w_instanceType == null || vars.w_instanceType.Current == vars.INSTANCE_LOADING || vars.deathOverrideActive);
}
