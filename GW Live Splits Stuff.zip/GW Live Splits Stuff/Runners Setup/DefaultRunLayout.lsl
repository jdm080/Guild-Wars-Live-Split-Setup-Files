﻿<?xml version="1.0" encoding="UTF-8"?>
<Layout version="1.6.1">
  <Mode>Vertical</Mode>
  <X>1829</X>
  <Y>368</Y>
  <VerticalWidth>260</VerticalWidth>
  <VerticalHeight>369</VerticalHeight>
  <HorizontalWidth>-1</HorizontalWidth>
  <HorizontalHeight>-1</HorizontalHeight>
  <Settings>
    <TextColor>FFFFFFFF</TextColor>
    <BackgroundColor>00000000</BackgroundColor>
    <BackgroundColor2>00000000</BackgroundColor2>
    <ThinSeparatorsColor>09FFFFFF</ThinSeparatorsColor>
    <SeparatorsColor>26FFFFFF</SeparatorsColor>
    <PersonalBestColor>FF16A6FF</PersonalBestColor>
    <AheadGainingTimeColor>FF29CC54</AheadGainingTimeColor>
    <AheadLosingTimeColor>FF70CC89</AheadLosingTimeColor>
    <BehindGainingTimeColor>FFCC7870</BehindGainingTimeColor>
    <BehindLosingTimeColor>FFCC3729</BehindLosingTimeColor>
    <BestSegmentColor>FFD8AF1F</BestSegmentColor>
    <UseRainbowColor>False</UseRainbowColor>
    <NotRunningColor>FF7A7A7A</NotRunningColor>
    <PausedColor>FF7A7A7A</PausedColor>
    <TextOutlineColor>00000000</TextOutlineColor>
    <ShadowsColor>80000000</ShadowsColor>
    <TimesFont><![CDATA[AAEAAAD/////AQAAAAAAAAAMAgAAAFFTeXN0ZW0uRHJhd2luZywgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWIwM2Y1ZjdmMTFkNTBhM2EFAQAAABNTeXN0ZW0uRHJhd2luZy5Gb250BAAAAAROYW1lBFNpemUFU3R5bGUEVW5pdAEABAQLGFN5c3RlbS5EcmF3aW5nLkZvbnRTdHlsZQIAAAAbU3lzdGVtLkRyYXdpbmcuR3JhcGhpY3NVbml0AgAAAAIAAAAGAwAAAAhTZWdvZSBVSQAAgEEF/P///xhTeXN0ZW0uRHJhd2luZy5Gb250U3R5bGUBAAAAB3ZhbHVlX18ACAIAAAABAAAABfv///8bU3lzdGVtLkRyYXdpbmcuR3JhcGhpY3NVbml0AQAAAAd2YWx1ZV9fAAgCAAAAAgAAAAs=]]></TimesFont>
    <TimerFont><![CDATA[AAEAAAD/////AQAAAAAAAAAMAgAAAFFTeXN0ZW0uRHJhd2luZywgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWIwM2Y1ZjdmMTFkNTBhM2EFAQAAABNTeXN0ZW0uRHJhd2luZy5Gb250BAAAAAROYW1lBFNpemUFU3R5bGUEVW5pdAEABAQLGFN5c3RlbS5EcmF3aW5nLkZvbnRTdHlsZQIAAAAbU3lzdGVtLkRyYXdpbmcuR3JhcGhpY3NVbml0AgAAAAIAAAAGAwAAAAdDYWxpYnJpAAAvQgX8////GFN5c3RlbS5EcmF3aW5nLkZvbnRTdHlsZQEAAAAHdmFsdWVfXwAIAgAAAAEAAAAF+////xtTeXN0ZW0uRHJhd2luZy5HcmFwaGljc1VuaXQBAAAAB3ZhbHVlX18ACAIAAAACAAAACw==]]></TimerFont>
    <TextFont><![CDATA[AAEAAAD/////AQAAAAAAAAAMAgAAAFFTeXN0ZW0uRHJhd2luZywgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWIwM2Y1ZjdmMTFkNTBhM2EFAQAAABNTeXN0ZW0uRHJhd2luZy5Gb250BAAAAAROYW1lBFNpemUFU3R5bGUEVW5pdAEABAQLGFN5c3RlbS5EcmF3aW5nLkZvbnRTdHlsZQIAAAAbU3lzdGVtLkRyYXdpbmcuR3JhcGhpY3NVbml0AgAAAAIAAAAGAwAAAAhTZWdvZSBVSQAAgEEF/P///xhTeXN0ZW0uRHJhd2luZy5Gb250U3R5bGUBAAAAB3ZhbHVlX18ACAIAAAAAAAAABfv///8bU3lzdGVtLkRyYXdpbmcuR3JhcGhpY3NVbml0AQAAAAd2YWx1ZV9fAAgCAAAAAgAAAAs=]]></TextFont>
    <AlwaysOnTop>True</AlwaysOnTop>
    <ShowBestSegments>True</ShowBestSegments>
    <AntiAliasing>True</AntiAliasing>
    <DropShadows>True</DropShadows>
    <BackgroundType>SolidColor</BackgroundType>
    <BackgroundImage />
    <ImageOpacity>1</ImageOpacity>
    <ImageBlur>0</ImageBlur>
    <Opacity>1</Opacity>
    <MousePassThroughWhileRunning>False</MousePassThroughWhileRunning>
  </Settings>
  <Components>
    <Component>
      <Path>LiveSplit.Timer.dll</Path>
      <Settings>
        <Version>1.5</Version>
        <TimerHeight>50</TimerHeight>
        <TimerWidth>225</TimerWidth>
        <TimerFormat>1.23</TimerFormat>
        <OverrideSplitColors>False</OverrideSplitColors>
        <ShowGradient>True</ShowGradient>
        <TimerColor>FFAAAAAA</TimerColor>
        <BackgroundColor>00FFFFFF</BackgroundColor>
        <BackgroundColor2>00FFFFFF</BackgroundColor2>
        <BackgroundGradient>Plain</BackgroundGradient>
        <CenterTimer>False</CenterTimer>
        <TimingMethod>Current Timing Method</TimingMethod>
        <DecimalsSize>35</DecimalsSize>
      </Settings>
    </Component>
    <Component>
      <Path>LiveSplit.Splits.dll</Path>
      <Settings>
        <Version>1.6</Version>
        <CurrentSplitTopColor>FF3373F4</CurrentSplitTopColor>
        <CurrentSplitBottomColor>FF153574</CurrentSplitBottomColor>
        <VisualSplitCount>8</VisualSplitCount>
        <SplitPreviewCount>1</SplitPreviewCount>
        <DisplayIcons>True</DisplayIcons>
        <ShowThinSeparators>True</ShowThinSeparators>
        <AlwaysShowLastSplit>True</AlwaysShowLastSplit>
        <SplitWidth>20</SplitWidth>
        <SplitTimesAccuracy>Seconds</SplitTimesAccuracy>
        <AutomaticAbbreviations>False</AutomaticAbbreviations>
        <BeforeNamesColor>FFFFFFFF</BeforeNamesColor>
        <CurrentNamesColor>FFFFFFFF</CurrentNamesColor>
        <AfterNamesColor>FFFFFFFF</AfterNamesColor>
        <OverrideTextColor>False</OverrideTextColor>
        <BeforeTimesColor>FFFFFFFF</BeforeTimesColor>
        <CurrentTimesColor>FFFFFFFF</CurrentTimesColor>
        <AfterTimesColor>FFFFFFFF</AfterTimesColor>
        <OverrideTimesColor>False</OverrideTimesColor>
        <ShowBlankSplits>True</ShowBlankSplits>
        <LockLastSplit>True</LockLastSplit>
        <IconSize>24</IconSize>
        <IconShadows>True</IconShadows>
        <SplitHeight>3.6</SplitHeight>
        <CurrentSplitGradient>Vertical</CurrentSplitGradient>
        <BackgroundColor>00FFFFFF</BackgroundColor>
        <BackgroundColor2>01FFFFFF</BackgroundColor2>
        <BackgroundGradient>Alternating</BackgroundGradient>
        <SeparatorLastSplit>True</SeparatorLastSplit>
        <DeltasAccuracy>Tenths</DeltasAccuracy>
        <DropDecimals>True</DropDecimals>
        <OverrideDeltasColor>False</OverrideDeltasColor>
        <DeltasColor>FFFFFFFF</DeltasColor>
        <Display2Rows>False</Display2Rows>
        <ShowColumnLabels>False</ShowColumnLabels>
        <LabelsColor>FFFFFFFF</LabelsColor>
        <Columns>
          <Settings>
            <Version>1.5</Version>
            <Name>+/-</Name>
            <Type>Delta</Type>
            <Comparison>Current Comparison</Comparison>
            <TimingMethod>Current Timing Method</TimingMethod>
          </Settings>
          <Settings>
            <Version>1.5</Version>
            <Name>Time</Name>
            <Type>SplitTime</Type>
            <Comparison>Current Comparison</Comparison>
            <TimingMethod>Current Timing Method</TimingMethod>
          </Settings>
        </Columns>
      </Settings>
    </Component>
    <Component>
      <Path>LiveSplit.ScriptableAutoSplit.dll</Path>
      <Settings>
        <Version>1.5</Version>
        <ScriptPath>C:\Users\joemi\Downloads\RunningV1(3).asl</ScriptPath>
        <Start>True</Start>
        <Reset>True</Reset>
        <Split>True</Split>
        <CustomSettings>
          <Setting id="EnableDeathReset" type="bool">True</Setting>
          <Setting id="EnableAutoReset" type="bool">True</Setting>
          <Setting id="BeaconsPerch" type="bool">False</Setting>
          <Setting id="GunnarsHold" type="bool">False</Setting>
          <Setting id="BorealStation" type="bool">False</Setting>
          <Setting id="AscalonCity" type="bool">False</Setting>
          <Setting id="LionsArch" type="bool">False</Setting>
          <Setting id="AmnoonOasis" type="bool">False</Setting>
          <Setting id="SunspearSanctuary" type="bool">False</Setting>
          <Setting id="YohlonHaven" type="bool">False</Setting>
          <Setting id="EnableDebugLogging" type="bool">True</Setting>
        </CustomSettings>
      </Settings>
    </Component>
    <Component>
      <Path>LiveSplit.Title.dll</Path>
      <Settings>
        <Version>1.7.3</Version>
        <ShowGameName>True</ShowGameName>
        <ShowCategoryName>True</ShowCategoryName>
        <ShowAttemptCount>True</ShowAttemptCount>
        <ShowFinishedRunsCount>False</ShowFinishedRunsCount>
        <OverrideTitleFont>False</OverrideTitleFont>
        <OverrideTitleColor>False</OverrideTitleColor>
        <TitleFont><![CDATA[AAEAAAD/////AQAAAAAAAAAMAgAAAFFTeXN0ZW0uRHJhd2luZywgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWIwM2Y1ZjdmMTFkNTBhM2EFAQAAABNTeXN0ZW0uRHJhd2luZy5Gb250BAAAAAROYW1lBFNpemUFU3R5bGUEVW5pdAEABAQLGFN5c3RlbS5EcmF3aW5nLkZvbnRTdHlsZQIAAAAbU3lzdGVtLkRyYXdpbmcuR3JhcGhpY3NVbml0AgAAAAIAAAAGAwAAAAhTZWdvZSBVSQAAgEEF/P///xhTeXN0ZW0uRHJhd2luZy5Gb250U3R5bGUBAAAAB3ZhbHVlX18ACAIAAAAAAAAABfv///8bU3lzdGVtLkRyYXdpbmcuR3JhcGhpY3NVbml0AQAAAAd2YWx1ZV9fAAgCAAAAAgAAAAs=]]></TitleFont>
        <SingleLine>False</SingleLine>
        <TitleColor>FFFFFFFF</TitleColor>
        <BackgroundColor>FF2A2A2A</BackgroundColor>
        <BackgroundColor2>FF131313</BackgroundColor2>
        <BackgroundGradient>Vertical</BackgroundGradient>
        <DisplayGameIcon>True</DisplayGameIcon>
        <ShowRegion>False</ShowRegion>
        <ShowPlatform>False</ShowPlatform>
        <ShowVariables>True</ShowVariables>
        <TextAlignment>0</TextAlignment>
      </Settings>
    </Component>
  </Components>
</Layout>