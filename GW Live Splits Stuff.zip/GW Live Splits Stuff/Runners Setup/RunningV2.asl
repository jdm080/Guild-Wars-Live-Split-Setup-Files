
state("Gw") { }

// ----------------------
// SETTINGS
// ----------------------
startup {
    settings.Add("EnableDeathReset", true, "Reset on Death");
    settings.Add("EnableAutoReset", true, "Map-Based Auto Reset");

    // Optional map-based reset locations
    settings.Add("BeaconsPerch", false, "Beacon's Perch");
    settings.Add("GunnarsHold", false, "Gunnar's Hold");
    settings.Add("BorealStation", false, "Boreal Station");
    settings.Add("AscalonCity", false, "Ascalon City");
    settings.Add("LionsArch", false, "Lion's Arch");
    settings.Add("AmnoonOasis", false, "The Amnoon Oasis");
    settings.Add("SunspearSanctuary", false, "Sunspear Sanctuary");
    settings.Add("YohlonHaven", false, "Yohlon Haven");

    settings.Add("EnableDebugLogging", false, "Enable Debug Logging");
}

// ----------------------
// INITIALIZATION
// ----------------------
init {
    vars.watchers = null;
    vars.wasLoading = false;
    vars.previousMapId = -1;
    vars.deathTriggered = false;
    vars.justStarted = null; // Prevent immediate split after start

    vars.INSTANCE_TOWN    = 0;
    vars.INSTANCE_EXPLORE = 1;
    vars.INSTANCE_LOADING = 2;

    vars.resetMaps = new Dictionary<string, int> {
        { "BeaconsPerch", 648 },
        { "GunnarsHold", 642 },
        { "BorealStation", 675 },
        { "AscalonCity", 81 },
        { "LionsArch", 55 },
        { "AmnoonOasis", 109 },
        { "SunspearSanctuary", 387 },
        { "YohlonHaven", 381 }
    };

    var scanner = new SignatureScanner(game, game.MainModule.BaseAddress, (int)game.MainModule.ModuleMemorySize);
    IntPtr ptrBase = scanner.Scan(new SigScanTarget(0xD, "6A 2C 50 E8 ?? ?? ?? ?? 83 C4 08 C7"));
    if (ptrBase == IntPtr.Zero) {
        if ((bool)settings["EnableDebugLogging"]) print("[INIT] Signature scan failed.");
        return;
    }

    vars.watchers = new MemoryWatcherList();
    vars.watchers.Add(new MemoryWatcher<int>(new DeepPointer(ptrBase, 0x4)) { Name = "instanceType" });
    vars.watchers.Add(new MemoryWatcher<int>(new DeepPointer("Gw.exe", 0xADDE74)) { Name = "mapId" });
    vars.watchers.Add(new MemoryWatcher<int>(new DeepPointer("Gw.exe", 0x7BE7BC)) { Name = "isDead" }); // 0 = alive, 1 = dead

    if ((bool)settings["EnableDebugLogging"]) print("[INIT] Watchers ready.");
}

// ----------------------
// UPDATE LOOP
// ----------------------
update {
    if (vars.watchers == null || game == null || game.HasExited) return;
    vars.watchers.UpdateAll(game);

    int deadFlag = vars.watchers["isDead"].Current;
    int type = vars.watchers["instanceType"].Current;
    int map = vars.watchers["mapId"].Current;

    // Mark death if setting is enabled
    if ((bool)settings["EnableDeathReset"] && deadFlag == 1) {
        vars.deathTriggered = true;
        if ((bool)settings["EnableDebugLogging"]) print("[DEATH] Detected.");
    }

    // Track loading state
    vars.wasLoading = (type == vars.INSTANCE_LOADING);

    // Clear justStarted automatically after one frame post-start
    if (vars.justStarted == true && timer.CurrentPhase == TimerPhase.Running) {
        vars.justStarted = false;
        if ((bool)settings["EnableDebugLogging"]) print("[FLAG] justStarted cleared after start.");
    }

    if ((bool)settings["EnableDebugLogging"]) {
        print("[U] type=" + type + " map=" + map + " dead=" + deadFlag);
    }
}

// ----------------------
// START CONDITION Checks if instanceType == Explorable.(if yes starts timer) Sets previousMapId and justStarted to block immediate split.
// ----------------------

start {
    if (vars.watchers == null) return false;

    int type = vars.watchers["instanceType"].Current;

    // ✅ Start whenever you are in an explorable area
    if (type == vars.INSTANCE_EXPLORE) {
        vars.previousMapId = vars.watchers["mapId"].Current;
        vars.justStarted = true; // Prevent immediate split
        if ((bool)settings["EnableDebugLogging"]) print("[START] Entered explorable area.");
        return true;
    }
    return false;
}


// ----------------------
// SPLIT CONDITION Checks splits if timer running+mapchange+not loading+not just started+if town/explorable. updates prev map ID
// ----------------------
split {
    if (vars.watchers == null || vars.justStarted == null) return false;

    int type = vars.watchers["instanceType"].Current;
    int map  = vars.watchers["mapId"].Current;
    bool mapChanged = (map != vars.previousMapId);

    if ((bool)settings["EnableDebugLogging"]) {
        print("[DEBUG SPLIT] mapChanged=" + mapChanged +
              " prevMap=" + vars.previousMapId +
              " currentMap=" + map +
              " justStarted=" + vars.justStarted +
              " wasLoading=" + vars.wasLoading +
              " type=" + type);
    }

    bool shouldSplit = timer.CurrentPhase == TimerPhase.Running
        && mapChanged
        && !vars.wasLoading
        && !vars.justStarted
        && (type == vars.INSTANCE_EXPLORE || type == vars.INSTANCE_TOWN);

    if (shouldSplit) {
        vars.previousMapId = map;
        if ((bool)settings["EnableDebugLogging"]) print("[SPLIT] Map change -> " + map);
        return true;
    }

    return false;
}

// ----------------------
// RESET CONDITION  checks for death/optional reset flags for towns.
// ----------------------
reset {
    if (vars.watchers == null) return false;

    int type = vars.watchers["instanceType"].Current;
    int mapId = vars.watchers["mapId"].Current;
    bool allowReset = false;

    if ((bool)settings["EnableDeathReset"] && vars.deathTriggered && type == vars.INSTANCE_TOWN) {
        allowReset = true;
        if ((bool)settings["EnableDebugLogging"]) print("[RESET] triggered by death -> town.");
    }

    if ((bool)settings["EnableAutoReset"]) {
        foreach (var entry in vars.resetMaps) {
            if ((bool)settings[entry.Key] && mapId == entry.Value) {
                allowReset = true;
                if ((bool)settings["EnableDebugLogging"]) print("[RESET] triggered by map -> " + entry.Key);
                break;
            }
        }
    }

    return allowReset;
}

// ----------------------
// ON RESET  mostly for clearing variables after you reset the run.
// ----------------------
onReset {
    vars.previousMapId = -1;
    vars.wasLoading = false;
    vars.deathTriggered = false;
    vars.justStarted = null;
    if ((bool)settings["EnableDebugLogging"]) print("[RESET] onReset: All flags cleared.");
}

// ----------------------
// LOADING CHECK   checks for loading frames/if in town
// ----------------------
isLoading {
    if (vars.watchers == null) return false;

    int type = vars.watchers["instanceType"].Current;
    return (type == vars.INSTANCE_LOADING || type == vars.INSTANCE_TOWN);
}